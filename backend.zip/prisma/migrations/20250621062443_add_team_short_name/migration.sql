-- AlterTable
ALTER TABLE "teams" ADD COLUMN "short_name" TEXT;
